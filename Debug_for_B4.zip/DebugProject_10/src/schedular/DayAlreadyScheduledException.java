package schedular;

public class DayAlreadyScheduledException extends Exception {

	public DayAlreadyScheduledException() {
		// TODO Auto-generated constructor stub
	}

	public DayAlreadyScheduledException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DayAlreadyScheduledException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public DayAlreadyScheduledException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}

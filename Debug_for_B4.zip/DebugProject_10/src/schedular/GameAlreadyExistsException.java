package schedular;

public class GameAlreadyExistsException extends Exception {

	public GameAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public GameAlreadyExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public GameAlreadyExistsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public GameAlreadyExistsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}

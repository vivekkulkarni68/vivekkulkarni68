package schedular;

public class InvalidGameException extends Exception {
	InvalidGameException(String name){
		super(name);
	}

}

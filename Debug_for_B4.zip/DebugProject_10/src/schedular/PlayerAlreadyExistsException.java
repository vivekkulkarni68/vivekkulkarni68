package schedular;

public class PlayerAlreadyExistsException extends Exception {

	public PlayerAlreadyExistsException() {
		// TODO Auto-generated constructor stub
	}

	public PlayerAlreadyExistsException(String arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PlayerAlreadyExistsException(Throwable arg0) {
		super(arg0);
		// TODO Auto-generated constructor stub
	}

	public PlayerAlreadyExistsException(String arg0, Throwable arg1) {
		super(arg0, arg1);
		// TODO Auto-generated constructor stub
	}

}

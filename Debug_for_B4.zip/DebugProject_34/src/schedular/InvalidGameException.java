package schedular;

public class InvalidGameException extends Exception {
	private InvalidGameException(String name){
		
	}

}

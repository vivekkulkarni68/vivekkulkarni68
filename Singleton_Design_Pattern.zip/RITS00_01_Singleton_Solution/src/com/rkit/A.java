package com.rkit;

public class A {
	private static A a = new A();

	private A() {
		System.out.println("A created");
	}

	public static final A getInstance() {
		return a;
	}

	public void finalize() {
		System.out.println("finalized");
	}

}

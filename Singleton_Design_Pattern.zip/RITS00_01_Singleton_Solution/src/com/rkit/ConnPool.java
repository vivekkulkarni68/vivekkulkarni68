package com.rkit;

public enum ConnPool {
	
	INSTANCE

}

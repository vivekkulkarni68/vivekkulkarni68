package com.rkit;

import java.sql.Connection;
import java.util.Vector;

public enum ConnPool_UsingEnum implements I {
	POOL {
		@Override
		public void doSomething() {
			System.out.println("Inside Instance");
			m1();
		}
	};
	private Vector<Connection> connections = new Vector<>();

	public void m1() {
		System.out.println("m1");
	}

	static {
		for (int i = 0; i < 5; i++) {
			System.out.println("Hello");
		}
	}

}

package com.rkit;

import java.io.Serializable;

public class ConnectionPool implements Serializable {
	// TODO#1 make this class singleton and run the test case to check if
	// It is singleton.
	private static final ConnectionPool pool = new ConnectionPool();

	private ConnectionPool() {
		if (pool != null)
			throw new IllegalAccessError();
	}

	public Object clone() throws CloneNotSupportedException {
		throw new CloneNotSupportedException();
	}

	public static ConnectionPool getInstance() {
		return pool;
	}

	public Object readResolve() {
		return pool;
	}

}

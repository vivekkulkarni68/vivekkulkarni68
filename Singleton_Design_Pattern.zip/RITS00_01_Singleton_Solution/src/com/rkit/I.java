package com.rkit;

public interface I {
	public void doSomething();

}

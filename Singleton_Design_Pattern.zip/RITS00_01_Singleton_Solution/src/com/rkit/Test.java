package com.rkit;

public class Test {

	public static void main(String[] args) {
		A a = A.getInstance();

		a = null;
//		System.gc();
//		try {
//			Thread.sleep(10000);
//		} catch (Exception ex) {
//			ex.printStackTrace();
//		}
		
		ConnPool p1 = ConnPool.INSTANCE;
		ConnPool p2 = ConnPool.INSTANCE;
		System.out.println(p1.getClass().getName());

	}

}

package test;

import com.rkit.ConnPool_UsingEnum;
import com.rkit.I;

public class TestSingleton_Enum {

	public static void main(String[] args) {
		I pool = ConnPool_UsingEnum.POOL;
		pool.doSomething();

	}

}

package com.rkit;

public class Account {
	private int accno;
	private String name; 
	private String pan;
	private Address addr;
	private int balance;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPan() {
		return pan;
	}
	public void setPan(String pan) {
		this.pan = pan;
	}
	public Address getAddr() {
		return addr;
	}
	public void setAddr(Address addr) {
		this.addr = addr;
	}
	public int getBalance() {
		return balance;
	}
	public void setBalance(int balance) {
		this.balance = balance;
	}
	public int getAccno() {
		return accno;
	}
	public void setAccno(int accno) {
		this.accno = accno;
	}
	public Account(int accno, String name, String pan, Address addr, int balance) {
		super();
		this.accno = accno;
		this.name = name;
		this.pan = pan;
		this.addr = addr;
		this.balance = balance;
	}
	public boolean equals(Object obj) {
		if(obj!=null) {
			Account acct = (Account)obj;
			return this.getName().equals(acct.getName());
		}
		return false;
	}
	public int hashCode() {
		return this.getName().hashCode();
	}

}

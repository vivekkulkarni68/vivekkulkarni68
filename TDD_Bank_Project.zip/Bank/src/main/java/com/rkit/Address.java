package com.rkit;

public class Address {
	
	private String city;
	private int pin;
	public Address(String city, int pin){
		this.city= city;
		this.pin = pin;
	}

}

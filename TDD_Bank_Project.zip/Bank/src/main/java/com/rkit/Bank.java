package com.rkit;

public interface Bank {
	int openAccount(String name,Address addr, String pan, int amount) throws InsufficientAmountException, BankException;
    int withdraw(int accno, int amount) throws InsufficientAmountException, BankException;
    int  deposit(int accno, int amount) throws BankException;
}

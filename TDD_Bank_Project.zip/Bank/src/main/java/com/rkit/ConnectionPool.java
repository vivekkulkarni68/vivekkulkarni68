package com.rkit;

import java.sql.Connection;
import java.util.ArrayList;
import java.util.List;

public class ConnectionPool {
	
	private static  ConnectionPool pool ;
	private ConnectionPool(){
		System.out.println("Obj of pool created !!");
	}
	
	public synchronized static ConnectionPool getConnectionPool() {
		//We will have to return object ref of this class
		if(pool==null) {
			pool = new ConnectionPool();
		}
		return pool;
	}
	
	
}

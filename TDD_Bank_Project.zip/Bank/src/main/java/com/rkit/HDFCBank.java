package com.rkit;

import java.util.HashSet;
import java.util.Set;

public class HDFCBank implements Bank{
	public static final int MIN_BALANCE=10000;
    private Set<Account> accounts = new HashSet();
    private int accountNumber=1001;
	@Override
	public int openAccount(String name, Address addr, String pan, int amount)
			throws InsufficientAmountException, BankException {
		if(name==null || pan==null||addr==null) {
			throw new BankException("Name is mandatory");
		}
		if(amount <MIN_BALANCE)
			throw new InsufficientAmountException("Min balance required is "+MIN_BALANCE);
		Account acct = new Account(accountNumber,name,pan,addr,amount);
		accounts.add(acct);
		return accountNumber++;
	}
	@Override
	public int withdraw(int accno, int amount) throws InsufficientAmountException, BankException {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public int deposit(int accno, int amount) throws BankException {
		// TODO Auto-generated method stub
		return 0;
	}
   

}

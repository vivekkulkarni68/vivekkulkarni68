package com.rkit;

import java.util.ArrayList;
import java.util.List;

public class Test {

	static List l = new ArrayList();
	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		
		Thread t1 = new Thread(()->{l.add(ConnectionPool.getConnectionPool()); System.out.println(l.size());});
		Thread t2 = new Thread(()->{l.add(ConnectionPool.getConnectionPool());System.out.println(l.size());});
		Thread t3 = new Thread(()->{l.add(ConnectionPool.getConnectionPool());System.out.println(l.size());});
		Thread t4 = new Thread(()->{l.add(ConnectionPool.getConnectionPool());});
		t1.start();
		t2.start();
		t3.start();
		t4.start();
		t1.join();
		t2.join();
		t3.join();
		t4.join();
		System.out.println(l.size());
		}

}

package com.rkit.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.rkit.Address;
import com.rkit.Bank;
import com.rkit.BankException;
import com.rkit.HDFCBank;
import com.rkit.InsufficientAmountException;

public class TestBank {


}

package com.rkit.test;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.rkit.Address;
import com.rkit.Bank;
import com.rkit.BankException;
import com.rkit.HDFCBank;
import com.rkit.InsufficientAmountException;

public class TestBank2 {

	
	  @Test public void testOpenAccountSuccessPath() { Bank bank = new HDFCBank();
	  try { assertEquals(1001, bank.openAccount("Vivek", new
	  Address("Pune",411004),"ABCD1234",HDFCBank.MIN_BALANCE)); } catch
	  (InsufficientAmountException | BankException e) { // TODO Auto-generated
	  e.printStackTrace();
	  }
	  }
	 
	
	  @Test(expected=BankException.class) public void
	  testOpenAccountErrorPathMissingName() throws BankException { Bank bank = new
	  HDFCBank();
	  
	  try { assertEquals(0, bank.openAccount(null, new
	  Address("Pune",411004),"ABCD1234",HDFCBank.MIN_BALANCE)); } catch
	  (InsufficientAmountException e) { // TODO Auto-generated catch block
	  e.printStackTrace(); } }
	 
	
	  @Test(expected=BankException.class) public void testOpenAccountErrorPathMissingAddress() throws BankException { Bank bank =
	  new HDFCBank();
	  
	  try { 
		  assertEquals(0, bank.openAccount("Vivek", null,"ABCD1234",HDFCBank.MIN_BALANCE)); 
	  }
	  catch (InsufficientAmountException e) 
	  { 
		  // TODO Auto-generated catch block e.printStackTrace(); 
	  }
		  
	  }
	 
	
	  @Test(expected=BankException.class) 
	  public void testOpenAccountErrorPathMissingPAN() throws BankException { Bank bank = new
	  HDFCBank(); try { assertEquals(0, bank.openAccount("Vivek", new
	  Address("Pune",411004),null,HDFCBank.MIN_BALANCE)); } catch
	  (InsufficientAmountException e) { // TODO Auto-generated catch block
	  e.printStackTrace(); }
	  
	  }
	 
	
	  @Test(expected=InsufficientAmountException.class) 
	  public void
	  testOpenAccountErrorPathInsufficientAMount() throws
	  InsufficientAmountException { Bank bank = new HDFCBank(); try {
	  assertEquals(0, bank.openAccount("Vivek", new
	  Address("Pune",411004),"ABCD1234",HDFCBank.MIN_BALANCE-1)); } catch
	  (BankException e) { // TODO Auto-generated catch block e.printStackTrace(); }
	  
	  }
	  }
	 

}
